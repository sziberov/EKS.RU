<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<title>Программы</title>
<link href="/css/index.css" type="text/css" rel="stylesheet">
<link rel="icon" type="image/svg+xml" href="/favicon.svg">
<meta name="robots" content="nofollow">

<meta http-equiv="content-language" content="ru">
<script src="/js/domain_title.js" charset="utf-8" type="text/javascript"></script>
<script src="/js/main.js" charset="utf-8" type="text/javascript"></script>
<script src="/js/request.js" charset="utf-8" type="text/javascript"></script>
<script src="/js/jquery-3.1.1.min.js" charset="utf-8" type="text/javascript"></script>
<script type="text/javascript">
if (window.top != window.self) window.top.location = window.self.location;
</script>
<script src="http://vk.com/js/api/share.js?90" charset="windows-1251" type="text/javascript"></script>

<meta name="description" content="Сервис хранения бесплатного ПО. EKS-программы. Скачать бесплатно.">
<meta name="keywords" content="сервис, хранение бесплатного по, программы, онлайн, скачать">
<meta property="og:image" content="/i/eks-3.png"/>
<link rel="image_src" href="/i/eks-3.png">
</head>

<body onload="initBody()">
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
<tr><td valign="top" style="height: 28px;">
<?php include($_SERVER['DOCUMENT_ROOT'] . "/include/header.php"); ?>
</td></tr>
<tr><td valign="top" style="padding: 16px;" id="body_element">

<!--<a href="/Видео"><h2>Видео</h2></a>-->
<h1>Видео</h1><br>
<p></p>
	<!--
	<table border="0" cellpadding="5" cellspacing="0">
		<tbody>
			<tr>
			<td>
				<img src="/i/arr_sg.gif" width="20" height="20" title="вы находитесь на первой странице">
			</td>
			<td>
				<img src="/i/arr_lg.gif" width="20" height="20" title="вы находитесь на первой странице">
			</td>
			<td>
				<font color="#808080"><b>1..8</b></font>
			</td>
			<td>
				<a href="/software.html&p=1">
					<img src="/i/arr_r.gif" border="0" width="20" height="20" title="перейти на следующую страницу">
				</a>
			</td>
			<td>
				<a href="/software.html&amp;p=1">9..16</a>
			<td>
				<a href="/software.html&amp;p=2">
					<img src="/i/arr_e.gif" border="0" width="20" height="20" title="перейти на последнюю страницу, всего позиций - 16">
				</a>
			</td>
		</tbody>
	</table>
	-->
<p></p>

<table width="100%" border="0" cellpadding="0" cellspacing="8" class="include_0"><tbody>

<?php
$category = 'domain_video';

include($_SERVER['DOCUMENT_ROOT'] . "/include/category_objects.php");
?>

</tbody></table>

<!--
<script>
$(document).ready(function () {
    var files = ['000001.html', '000002.html', '000003.html'];

        for (i = 0; i <= files.length; i++) {
            jQuery.get(files[i], function (data) {

                var htmlstr = $.parseHTML(data);
                //alert($(htmlstr).filter('title')[0].text);
			    $('#test').append($(htmlstr).filter('title')[0].text);
            });
        }
});
</script>
<div id="test"></div>
-->

<p></p>
<!--Arrows post-->

<?php include($_SERVER['DOCUMENT_ROOT'] . "/include/share.html"); ?>

</td></tr>
<tr><td valign="bottom" height="32">
<?php include($_SERVER['DOCUMENT_ROOT'] . "/include/footer.html"); ?>
</td></tr>
</tbody></table>
</body></html>